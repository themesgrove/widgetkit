<?php
/**
 * Silence is golden
 *
 * @package  WidgetKit For Elementor
 * @category Core
 * @author   Themesgrove
 * @license  GPL-3+
 */